This repo contain source codes for a Ionic-React App with Google Maps API.

After cloning the repository with git clone repository-url

Change to the project directory: cd project-directory

Install the required dependencies listed in package.json with: npm install --legacy-peer-deps

Finally you can run the application with:  ionic serve
