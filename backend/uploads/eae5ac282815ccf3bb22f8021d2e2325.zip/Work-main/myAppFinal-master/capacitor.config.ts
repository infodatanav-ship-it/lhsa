import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.impactmaps.app',
  appName: 'Impact Maps',
  webDir: 'dist'
};

export default config;
