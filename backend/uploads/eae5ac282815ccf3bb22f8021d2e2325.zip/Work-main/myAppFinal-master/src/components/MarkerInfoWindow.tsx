import React from 'react';
import { IonButton, IonCol, IonContent, IonGrid, IonIcon, IonLabel, IonNote, IonRow } from '@ionic/react';
import { globeOutline, locationOutline, phonePortraitOutline } from "ionicons/icons";


interface Marker {
    title: string;
    description: string;
    location: string;
    email: string;
    contact: string;
}


interface MarkerInfoWindowProps {
    marker: Marker;
    dismiss: () => void;
}

export const MarkerInfoWindow: React.FC<MarkerInfoWindowProps> = ({ marker, dismiss }) => {
    return (
        <IonContent>
            <IonGrid className="ion-padding">
                <IonRow className="ion-margin-bottom">
                    <IonCol size="12">
                        <IonLabel>
                            <h1>{marker.title}</h1>
                            <IonNote>{marker.description}</IonNote>
                        </IonLabel>
                    </IonCol>
                </IonRow>
                <IonRow className="ion-justify-content-start ion-align-items-center">
                    <IonCol size="2">
                        <IonIcon icon={locationOutline} color="primary" style={{ fontSize: "1.5rem" }} />
                    </IonCol>
                    <IonCol size="10">{marker.location}</IonCol>
                </IonRow>
                <IonRow className="ion-justify-content-start ion-align-items-center">
                    <IonCol size="2">
                        <IonIcon icon={globeOutline} color="primary" style={{ fontSize: "1.5rem" }} />
                    </IonCol>
                    <IonCol size="10">{marker.email}</IonCol>
                </IonRow>
                <IonRow className="ion-justify-content-start ion-align-items-center">
                    <IonCol size="2">
                        <IonIcon icon={phonePortraitOutline} color="primary" style={{ fontSize: "1.5rem" }} />
                    </IonCol>
                    <IonCol size="10">{marker.contact}</IonCol>
                </IonRow>
            </IonGrid>
        </IonContent>
    );
};

