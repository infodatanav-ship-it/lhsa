// src/components/BusinessModal.tsx
import React, { useEffect } from 'react';
import {
  IonModal,
  IonButton,
  IonInput,
  IonItem,
  IonLabel,
} from '@ionic/react';

interface Business {
  id: number;
  name: string;
  contactNumber: string;
  email: string;
}

interface BusinessModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (business: Business) => void;
  existingBusiness?: Business;
}

const BusinessModal: React.FC<BusinessModalProps> = ({ isOpen, onClose, onSubmit, existingBusiness }) => {
  const [newBusiness, setNewBusiness] = React.useState<Business>({
    id: existingBusiness ? existingBusiness.id : 0,
    name: existingBusiness ? existingBusiness.name : '',
    contactNumber: existingBusiness ? existingBusiness.contactNumber : '',
    email: existingBusiness ? existingBusiness.email : '',
  });

  useEffect(() => {
    if (existingBusiness) {
      setNewBusiness(existingBusiness);
    }
  }, [existingBusiness]);

  const handleSubmit = () => {
    onSubmit(newBusiness);
    onClose();
  };

  return (
    <IonModal isOpen={isOpen} onDidDismiss={onClose}>
      <div style={{ padding: '20px' }}>
        <IonItem>
          <IonLabel position="stacked">Business Name</IonLabel>
          <IonInput
            value={newBusiness.name}
            onIonChange={e => setNewBusiness({ ...newBusiness, name: e.detail.value! })}
          />
        </IonItem>
        <IonItem>
          <IonLabel position="stacked">Contact Number</IonLabel>
          <IonInput
            value={newBusiness.contactNumber}
            onIonChange={e => setNewBusiness({ ...newBusiness, contactNumber: e.detail.value! })}
          />
        </IonItem>
        <IonItem>
          <IonLabel position="stacked">Email</IonLabel>
          <IonInput
            value={newBusiness.email}
            onIonChange={e => setNewBusiness({ ...newBusiness, email: e.detail.value! })}
          />
        </IonItem>
        <IonButton expand="full" onClick={handleSubmit}>
          {existingBusiness ? 'Update' : 'Add'} Business
        </IonButton>
        <IonButton expand="full" color="medium" onClick={onClose}>
          Cancel
        </IonButton>
      </div>
    </IonModal>
  );
};

export default BusinessModal;
