import React, { useState } from 'react';
import { IonModal, IonButton, IonItem, IonLabel } from '@ionic/react';
import axios from 'axios';

interface FileUploadModalProps {
	isOpen: boolean;
	onClose: () => void;
	onSubmit: (file: File) => void;
}

const UploadModal: React.FC<FileUploadModalProps> = ({ isOpen, onClose, onSubmit }) => {
	const [file, setFile] = useState<File | null>(null);

	const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
		const selectedFile = event.target.files?.[0] || null;
		setFile(selectedFile);
	};

	const handleSubmit = async () => {
		if (file) {
			const formData = new FormData();
			formData.append('file', file);

			try {
				await axios.post('http://httpbin.org/post', formData, {
					headers: {
						'Content-Type': 'multipart/form-data',
					},
				});
				onSubmit(file);
				onClose();
			} catch (error) {
				console.error('Error uploading file:', error);
			}
		}
	};

	return (
		<IonModal isOpen={isOpen} onDidDismiss={onClose}>
			<div style={{ padding: '20px' }}>
				<IonItem>
					<IonLabel>Select File</IonLabel>
					<input type="file" onChange={handleFileChange} />
				</IonItem>
				<IonButton expand="full" onClick={handleSubmit} disabled={!file}>
					Upload File
				</IonButton>
				<IonButton expand="full" color="medium" onClick={onClose}>
					Cancel
				</IonButton>
			</div>
		</IonModal>
	);
};

export default UploadModal;
