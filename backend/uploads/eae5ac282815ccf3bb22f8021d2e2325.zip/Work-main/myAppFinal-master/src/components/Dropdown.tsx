import React from 'react';
import { IonSelect, IonSelectOption } from '@ionic/react';

export interface SelectOption {
  id: number;
  name: string;
}

export interface DropdownProps {
  options: SelectOption[]; // Accept options as a prop
  onSelectionChange?: (selectedId: number | undefined) => void;
  placeholder: string;
}

const Dropdown: React.FC<DropdownProps> = ({ options, onSelectionChange, placeholder }) => {
  const handleSelectChange = (event: CustomEvent) => {
    const selectedId = event.detail.value as number | undefined; // Ensure value is of type number or undefined
    if (onSelectionChange) {
      onSelectionChange(selectedId);
    }
  };

  return (
    <IonSelect
      placeholder={placeholder}
      onIonChange={handleSelectChange}
      style={{ width: '100%', maxWidth: '400px', margin: '0 auto' }}
    >
      {options.map((option) => (
        <IonSelectOption key={option.id} value={option.id}>
          {option.name}
        </IonSelectOption>
      ))}
    </IonSelect>
  );
};

export default Dropdown;
