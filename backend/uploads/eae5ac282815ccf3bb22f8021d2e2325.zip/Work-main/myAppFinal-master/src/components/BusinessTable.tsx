// src/components/BusinessTable.tsx
import React from 'react';
import DataTable from 'react-data-table-component';
import { IonButton, IonGrid, IonIcon } from '@ionic/react';
import { cloudUpload, pencil, pencilOutline, trash, trashOutline } from 'ionicons/icons';
import './BusinessTable.css';

interface Business {
  id: number;
  name: string;
  contactNumber: string;
  email: string;
}

interface BusinessTableProps {
  businesses: Business[];
  onUpdate: (business: Business) => void;
  onDelete: (id: number) => void;

}

const customStyles = {
  rows: {
    style: {
      backgroundColor: 'black', 
      color: 'white',          
      fontSize:'12px',
      padding:'5px'

    },
  },
  headCells: {
    style: {
      backgroundColor: '#333',
      color: 'white', 
      fontSize:'12px',
      padding:'5px'       
    },
  },
  cells: {
    style: {
      backgroundColor: 'black', 
      color: 'white',  
      fontSize:'12px',
      padding:'1px'         
    },
  },
  pagination: {
    style: {
      backgroundColor: '#333', 
      color: 'white',          
    },
  },
  paginationButton: {
    style: {
      backgroundColor: 'black', 
      color: 'white',           
    },
  },
  paginationSelect: {
    style: {
      backgroundColor: '#333',  
      color: 'white',           
    },
  },
};



const BusinessTable: React.FC<BusinessTableProps> = ({ businesses, onUpdate, onDelete }) => {
  
  const columns = [
    {
      name: 'Business Name',
      selector: (row: Business) => row.name,
      sortable: true,
      width: '30%', 
    },
    
    {
      name: 'Email',
      selector: (row: Business) => row.email,
      sortable: true,
      width: '35%',
    },
    {
      name: 'Actions',
      width: '35%',
      cell: (row: Business) => (
        <div style={{ display: 'flex', gap: '0px', alignContent:'space-between' }}>
          <IonButton onClick={() => onUpdate(row)} color="secondary" fill="clear">
            <IonIcon icon={pencil} />
          </IonButton>
          <IonButton onClick={() => onDelete(row.id)} color="danger" fill="clear">
            <IonIcon icon={trash} />
          </IonButton>
          {/* <IonButton color="primary" fill="clear">
            <IonIcon icon={cloudUpload} />
          </IonButton> */}
        </div>
      ),
    },
  ];

  return (
    <IonGrid>
    <DataTable
      columns={columns}
      data={businesses}
      pagination
      highlightOnHover
      pointerOnHover
      customStyles={customStyles}
    />
     </IonGrid>
  );
};

export default BusinessTable;