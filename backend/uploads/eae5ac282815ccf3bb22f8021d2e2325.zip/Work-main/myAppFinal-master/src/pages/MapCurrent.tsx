import { GoogleMap } from '@capacitor/google-maps';
import { IonContent, IonPage, IonHeader, IonToolbar, IonTitle, IonIcon, IonButton, useIonRouter } from '@ionic/react';
import React, { useRef, useEffect, useState } from 'react';
import { Geolocation } from '@capacitor/geolocation';
import { locationOutline, logOutOutline, businessOutline, searchOutline } from 'ionicons/icons';
// import { useHistory } from 'react-router-dom';
import Dropdown, { SelectOption } from '../components/Dropdown';

const MapCurrent: React.FC = () => {

	const router = useIonRouter();

	const mapRef = useRef<HTMLDivElement>(null);
	const [map, setMap] = useState<GoogleMap | undefined>(undefined);
	const [provinceOptions, setProvinceOptions] = useState<SelectOption[]>([]);
	const [assetOptions, setAssetOptions] = useState<SelectOption[]>([]);
	const [serviceOptions, setServiceOptions] = useState<SelectOption[]>([]);
	const [radiusOptions] = useState<SelectOption[]>([]); // Adjust as needed
	const [selectedRadius, setSelectedRadius] = useState<number | undefined>(undefined);
	// const history = useHistory();

	// bevan paulse

	const fetchProvinces = async () => {
		try {
			const response = await fetch('https://geotaggingapi.azurewebsites.net/api/provinces');
			const data = await response.json();
			const options = mapResponseToOptions(data);
			setProvinceOptions(options);
		} catch (error) {
			console.error('Error fetching provinces:', error);
		}
	};

	const handleMarkerClick = () => {
		alert("Marker clicked!");
	};

	const createMap = async (latitude: number, longitude: number) => {
		try {
			if (!mapRef.current) {
				console.error('Map container is not available.');
				return;
			}

			const newMap = await GoogleMap.create({
				id: 'my-cool-map',
				element: mapRef.current,
				apiKey: "AIzaSyAVrErDoM2HMFklE27IOUL2QB_-qf3Mo0A",
				config: {
					center: {
						lat: latitude,
						lng: longitude,
					},
					zoom: 15,
				},
			});

			setMap(newMap);

			await newMap.addMarker({
				coordinate: {
					lat: latitude,
					lng: longitude,
				},
				title: "You are here",
				snippet: "This is your current location"
			});

			// centreMarker.addListener("click", () => {
			// 	alert("Marker clicked!");
			// });

			await newMap.addCircles([{
				center: {
					lat: latitude,
					lng: longitude,
				},
				radius: 10000,
				strokeColor: '#FF0000',
				//strokeWidth: 2,
				fillColor: '#FF0000',
				fillOpacity: 0.35,
			}]);


			console.log('Marker and circle added successfully.');

		} catch (error) {
			console.error('Error creating map or adding marker:', error);
		}
	};

	const getCurrentLocation = async () => {
		try {
			const position = await Geolocation.getCurrentPosition();
			console.log('Current Position:', position);
			createMap(position.coords.latitude, position.coords.longitude);
		} catch (error) {
			console.error('Error getting current position:', error);
		}
	};

	useEffect(() => {
		fetchProvinces();
		getCurrentLocation();

		return () => {
			map?.destroy();
		};
	}, []);

	const handleLogout = () => {
		// history.push('/login');
		router.push('/login');
	};

	const handleBackToBusinessServices = () => {
		// history.push('/business_services');
		router.push('/business_services');
	};

	return (
		<IonPage>
			<IonHeader>
				<IonToolbar>
					<div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', width: '100%', padding: '0 16px' }}>
						<IonButton onClick={handleBackToBusinessServices} style={{ backgroundColor: '#0040ff', color: 'white', marginRight: '8px' }}>
							<IonIcon slot="start" icon={businessOutline} />
							Businesses
						</IonButton>
						<div style={{ display: 'flex', alignItems: 'center', flex: 1, justifyContent: 'center' }}>
							<IonTitle style={{ flex: 1, textAlign: 'center', marginRight: '8px' }}>
								Your Current Location
								<IonIcon icon={locationOutline} style={{ fontSize: '24px', color: 'white', marginLeft: '5px' }} />
							</IonTitle>
						</div>
						<IonButton onClick={handleLogout} style={{ backgroundColor: '#0040ff', color: 'white', marginLeft: '8px' }}>
							<IonIcon slot="start" icon={logOutOutline} />
							Logout
						</IonButton>
					</div>
				</IonToolbar>
			</IonHeader>

			<IonContent>
				<div style={{ width: '100%', margin: 'auto', alignItems: 'center', border: "1px solid white" }}>
					<div style={{ textAlign: "center" }}>
						<h1>
							Search Businesses
						</h1>
					</div>

					<div style={{ marginBottom: '5px', border: "1px solid white" }}>
						<Dropdown options={provinceOptions} onSelectionChange={(id) => { }} placeholder='Select a Province' />
					</div>
					<div style={{ marginBottom: '5px', border: "1px solid white" }}>
						<Dropdown options={assetOptions} onSelectionChange={(id) => { }} placeholder='Select an Asset' />
					</div>
					<div style={{ marginBottom: '5px', border: "1px solid white" }}>
						<Dropdown options={serviceOptions} onSelectionChange={(id) => { }} placeholder='Select a Service' />
					</div>
					<div style={{ marginBottom: '5px', border: "1px solid white" }}>
						<Dropdown options={radiusOptions} onSelectionChange={setSelectedRadius} placeholder='Select Radius' />
					</div>
					<div style={{ width: "94%" }}>
						<IonButton style={{ backgroundColor: '#0040ff', width: "100%", color: 'black', marginLeft: '18px' }}>
							<IonIcon slot="start" icon={searchOutline} />
							Search
						</IonButton>
					</div>

					<div
						ref={mapRef}
						style={{
							width: '95%',
							height: '320px',
							position: 'relative',
							overflow: 'hidden',
							margin: 'auto',
							boxSizing: 'border-box',
						}}
					></div>
				</div>
			</IonContent>
		</IonPage>
	);
};

const mapResponseToOptions = (data: any[]): SelectOption[] => {
	return data.map((item) => ({
		id: item.id,
		name: item.name || item.settingName,
	}));
};

export default MapCurrent;
