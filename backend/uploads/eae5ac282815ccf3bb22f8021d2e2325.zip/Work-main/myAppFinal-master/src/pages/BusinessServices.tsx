import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { IonContent, IonHeader, IonPage, IonTitle, IonToolbar, IonButton, IonIcon, IonInput, IonToast, IonMenu, IonMenuButton, IonList, IonItem, IonSplitPane, IonMenuToggle, IonGrid } from '@ionic/react';
import { locationOutline, logOutOutline, businessOutline } from 'ionicons/icons';
import BusinessTable from '../components/BusinessTable';
import BusinessModal from '../components/BusinessModal';
import FileUploadModal from '../components/FileUploadModal';
import { useHistory } from 'react-router-dom';

// Update the Business interface
interface Business {
	id: number;
	name: string;
	contactNumber: string;
	email: string;
	companyname: string;
	surname: string;
	funder: string;
	website: string;
	classification: string;
	programmemanager: string;
	coreservices: string;
	landline: string;
	businessType: string;
}

const BusinessServices: React.FC = () => {
	const history = useHistory(); // Uncomment if you're using routing

	// State hooks
	const [businesses, setBusinesses] = useState<Business[]>([]);
	const [showModal, setShowModal] = useState(false);
	const [showUploadModal, setShowUploadModal] = useState(false);
	const [currentBusiness, setCurrentBusiness] = useState<any>(null);
	const [searchQuery, setSearchQuery] = useState('');
	const [filteredBusinesses, setFilteredBusinesses] = useState<Business[]>([]);
	const [toastMessage, setToastMessage] = useState('');
	const [showToast, setShowToast] = useState(false);
	const [loading, setLoading] = useState<boolean>(false);
	const [error, setError] = useState<string>('');

	// Fetch businesses using useEffect and axios
	useEffect(() => {
		const fetchBusinesses = async () => {
			setLoading(true);
			setError('');
			try {
				const response = await axios.get('https://geotaggingapi.azurewebsites.net/api/businesses');
				setBusinesses(response.data); 
				setFilteredBusinesses(response.data); 
			} catch (err) {
				setError('Failed to fetch businesses');
			} finally {
				setLoading(false);
			}
		};

		fetchBusinesses();
	}, []);

	// Handle business update
	const handleUpdate = (business: any) => {
		setCurrentBusiness(business);
		setShowModal(true);
	};

	// Handle business deletion
	const handleDelete = (id: number) => {
		const updatedBusinesses = businesses.filter(b => b.id !== id);
		setBusinesses(updatedBusinesses);
		setFilteredBusinesses(updatedBusinesses);
	};

	// Handle form submit for business
	const handleSubmit = (business: any) => {
		if (currentBusiness) {
			setBusinesses(businesses.map(b => (b.id === currentBusiness.id ? { ...b, ...business } : b)));
			setFilteredBusinesses(businesses);
		} else {
			const id = businesses.length ? businesses[businesses.length - 1].id + 1 : 1;
			const newBusinessList = [...businesses, { id, ...business }];
			setBusinesses(newBusinessList);
			setFilteredBusinesses(newBusinessList);
		}
		setShowModal(false);
		setCurrentBusiness(null);
	};

	// Handle search
	const handleSearch = (query: string) => {
		const results = businesses.filter(business =>
			business.name.toLowerCase().includes(query.toLowerCase())
		);
		setFilteredBusinesses(results);
	};

	// Handle logout (this function is left as a placeholder)
	const handleLogout = () => {
		// history.push('/login'); // Uncomment if using routing
	};

	// Handle back to map page (this function is left as a placeholder)
	const handleBackToMapCurrent = () => {
		// history.push('/mapcurrent'); // Uncomment if using routing
	};

	// Loading and error handling UI
	if (loading) {
		return (
			<IonContent>
				<IonTitle>Loading...</IonTitle>
			</IonContent>
		);
	}

	if (error) {
		return (
			<IonContent>
				<IonTitle>{error}</IonTitle>
			</IonContent>
		);
	}

	return (
		<IonSplitPane contentId="main-content">
			<IonMenu contentId="main-content" side="end">
				<IonHeader>
					<IonToolbar>
						<IonTitle>Menu</IonTitle>
					</IonToolbar>
				</IonHeader>

				<IonContent>
					<IonList>
						<IonItem button onClick={handleBackToMapCurrent}>
							<IonIcon slot="start" icon={businessOutline} />
							Back to Map
						</IonItem>
						<IonItem button onClick={handleLogout}>
							<IonIcon slot="start" icon={logOutOutline} />
							Logout
						</IonItem>
					</IonList>
				</IonContent>
			</IonMenu>

			<IonPage id="main-content">
				<IonHeader>
					<IonToolbar>
						<IonMenuButton slot="end" />
						<IonTitle style={{ textAlign: 'center' }}>Business Services</IonTitle>
					</IonToolbar>
				</IonHeader>
				<IonContent fullscreen>
					<div style={{ display: 'flex', alignItems: 'center', margin: '16px' }}>
						<IonInput
							value={searchQuery}
							placeholder="Search by business name"
							onIonInput={e => {
								const query = String((e.target as HTMLIonInputElement).value) || '';
								setSearchQuery(query);
								handleSearch(query);
							}}
							style={{ marginRight: '8px', flex: 1 }}
						/>
					</div>
					<div style={{ overflowX: 'auto' }}>
						<IonGrid>
							<BusinessTable
								businesses={filteredBusinesses}
								onUpdate={handleUpdate}
								onDelete={handleDelete}
							/>
						</IonGrid>
					</div>
					<IonButton
						className="ion-padding"
						onClick={() => setShowModal(true)}
						expand="full"
						style={{ padding: '5px', marginTop: '10px' }}
					>
						Add Business
					</IonButton>
					<BusinessModal
						isOpen={showModal}
						onClose={() => setShowModal(false)}
						onSubmit={handleSubmit}
						existingBusiness={currentBusiness}
					/>
					<IonButton
						className="ion-padding"
						onClick={() => setShowUploadModal(true)}
						expand="full"
						style={{ padding: '5px', marginTop: '10px' }}
					>
						Upload File
					</IonButton>
					<FileUploadModal
						isOpen={showUploadModal}
						onClose={() => setShowUploadModal(false)}
						onSubmit={file => {
							setToastMessage('File uploaded successfully!');
							setShowToast(true);
							console.log('File uploaded:', file);
						}}
					/>
					<IonToast
						isOpen={showToast}
						onDidDismiss={() => setShowToast(false)}
						message={toastMessage}
						duration={2000}
					/>
				</IonContent>
			</IonPage>
		</IonSplitPane>
	);
};

export default BusinessServices;
